export type specifications = {
    _id:string;
    name:string,
}
export type specificationsDetail = {
    _id:string;
    id_specification: string,
    name:string,
}