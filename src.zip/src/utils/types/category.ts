export type category = {
    _id: string,
    name: string,
    thumbnail: string,
    slug: string,
}