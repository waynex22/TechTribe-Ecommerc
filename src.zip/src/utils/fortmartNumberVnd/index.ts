export const formatNumberVnd = (number: number) => {
    return 'đ ' + number.toLocaleString('vi-VN')
}