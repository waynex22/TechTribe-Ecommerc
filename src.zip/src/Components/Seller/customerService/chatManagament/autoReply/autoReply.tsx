import React from 'react'

const AutoReplyComponent: React.FC = () => {
  return (
    <div>AutoReplyComponent</div>
  )
}

export default AutoReplyComponent