import React from 'react';

const ComponentUserAccount: React.FC = () => {
    return (
        <>
        </>
    )
}

export default ComponentUserAccount;
